package my.bundles;

public class B {
	
	public void startSomething() {
		aPrivateMethod();
	}
	
	private void aPrivateMethod() {
		new A().aPackageMethod();
		new A().aProtectedMethod();
	}

}
