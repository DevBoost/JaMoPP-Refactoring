package my.bundles;

public class A {
	
	void aPackageMethod() {

	}

	protected void aProtectedMethod() {

	}
}
