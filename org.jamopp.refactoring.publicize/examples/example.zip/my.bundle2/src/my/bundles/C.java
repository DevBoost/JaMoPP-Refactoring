package my.bundles;

public class C {
	
	public void aMethod() {
		new A().aPackageMethod();
		new A().aProtectedMethod();
	}
	
}
